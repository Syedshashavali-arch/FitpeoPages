package Stepdefinition;

import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks {
	WebDriver driver = new ChromeDriver();

	@Before
	public void setup() {
		WebDriverManager.chromedriver().setup();
		driver.manage().window().maximize();
		
	}
	
	@Given("Launch the url")
	public void launch_the_url() {
		driver.navigate().to("https://www.fitpeo.com/cpt-codes");

	}

	@Then("Click on the revenue calculator section")
	public void click_on_the_revenue_calculator_section() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("The Revenue calculator page loads")
	public void the_revenue_calculator_page_loads() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Scroll down to Medicare Eligible Patients section")
	public void scroll_down_to_medicare_eligible_patients_section() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Adjust the slider to {int} bottom text field value should be updated to {int}")
	public void adjust_the_slider_to_bottom_text_field_value_should_be_updated_to(Integer int1, Integer int2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Update the value in the input field enter {int}")
	public void update_the_value_in_the_input_field_enter(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Validate the slider position and value is reflected accordingly")
	public void validate_the_slider_position_and_value_is_reflected_accordingly() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Scroll down to CPT codes section to select CPT-{int}, CPT-{int}, CPT-{int}, and CPT-{int} checkboxes")
	public void scroll_down_to_cpt_codes_section_to_select_cpt_cpt_cpt_and_cpt_checkboxes(Integer int1, Integer int2, Integer int3, Integer int4) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Validate header displaying Total Recurring Reimbursement for all Patients Per Month: shows the�value�${int}")
	public void validate_header_displaying_total_recurring_reimbursement_for_all_patients_per_month_shows_the_value_$(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


	@After
	public void teardown() {
		driver.close();
		driver.quit();
	}
}